package christmasPastryShop.entities.drinks;

public class MulledWine extends BaseCocktail {

    public MulledWine(String name, int size, String brand) {
        super(name, size, 3.50, brand);
    }
}
