package P02MultipleImplementation;

public interface Identifiable {

    String getId();
}
