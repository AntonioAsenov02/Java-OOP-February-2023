package P03BirthdayCelebrations;

public interface Identifiable {

    String getId();
}
