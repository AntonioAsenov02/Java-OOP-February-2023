package P05Telephony;

public interface Callable {

    String call();

}
