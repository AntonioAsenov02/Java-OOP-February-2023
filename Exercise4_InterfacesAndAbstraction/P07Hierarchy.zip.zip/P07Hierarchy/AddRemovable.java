package P07Hierarchy;

public interface AddRemovable extends Addable{

    String remove();
}
