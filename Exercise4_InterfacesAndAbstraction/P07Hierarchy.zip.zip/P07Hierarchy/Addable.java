package P07Hierarchy;

public interface Addable {

    int add(String item);
}
