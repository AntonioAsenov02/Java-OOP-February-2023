package P01Vehicles;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String [] carInfo = scanner.nextLine().split("\\s+");

        double carFuelQuantity = Double.parseDouble(carInfo[1]);
        double carFuelConsumption = Double.parseDouble(carInfo[2]);

        String [] truckInfo = scanner.nextLine().split("\\s+");

        double truckFuelQuantity = Double.parseDouble(truckInfo[1]);
        double truckFuelConsumption = Double.parseDouble(truckInfo[2]);

        Vehicle car = new Car(carFuelQuantity,carFuelConsumption);
        Vehicle truck = new Truck(truckFuelQuantity,truckFuelConsumption);

        int numberOfCommands = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= numberOfCommands ; i++) {

            String [] input = scanner.nextLine().split("\\s+");

            String command = input[0];
            String objectType = input[1];


            switch (objectType){
                case "Car" :
                    if (command.equals("Drive")){

                        double distance = Double.parseDouble(input[2]);
                        System.out.println(car.drive(distance));
                    }else {
                        double liters = Double.parseDouble(input[2]);
                        car.refuel(liters);
                    }
                    break;
                case "Truck" :
                    if (command.equals("Drive")){

                        double distance = Double.parseDouble(input[2]);
                        System.out.println(truck.drive(distance));
                    }else {
                        double liters = Double.parseDouble(input[2]);
                        truck.refuel(liters);
                    }
                    break;
            }
        }
        System.out.println(car);
        System.out.println(truck);
    }
}
