package blackBoxInteger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchFieldException {

        Scanner scanner = new Scanner(System.in);

        Class<BlackBoxInt> clazz = BlackBoxInt.class;

        Constructor<BlackBoxInt> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);

        BlackBoxInt blackBoxInt = constructor.newInstance();

        Field innerValue = clazz.getDeclaredField("innerValue");
        innerValue.setAccessible(true);

        String command = scanner.nextLine();

        while (!command.equals("END")){

            String [] commandArr = command.split("_");

            String method = commandArr[0];
            int number = Integer.parseInt(commandArr[1]);

            switch (method){
                case "add" :
                    Method add = clazz.getDeclaredMethod("add", int.class);
                    add.setAccessible(true);
                    add.invoke(blackBoxInt,number);
                    System.out.println(innerValue.get(blackBoxInt));
                    break;
                case "subtract" :
                    Method subtract = clazz.getDeclaredMethod("subtract", int.class);
                    subtract.setAccessible(true);
                    subtract.invoke(blackBoxInt,number);
                    System.out.println(innerValue.get(blackBoxInt));
                    break;
                case "multiply" :
                    Method multiply = clazz.getDeclaredMethod("multiply", int.class);
                    multiply.setAccessible(true);
                    multiply.invoke(blackBoxInt,number);
                    System.out.println(innerValue.get(blackBoxInt));
                    break;
                case "divide" :
                    Method divide = clazz.getDeclaredMethod("divide", int.class);
                    divide.setAccessible(true);
                    divide.invoke(blackBoxInt,number);
                    System.out.println(innerValue.get(blackBoxInt));
                    break;
                case "leftShift" :
                    Method leftShift = clazz.getDeclaredMethod("leftShift", int.class);
                    leftShift.setAccessible(true);
                    leftShift.invoke(blackBoxInt,number);
                    System.out.println(innerValue.get(blackBoxInt));
                    break;
                case "rightShift" :
                    Method rightShift = clazz.getDeclaredMethod("rightShift", int.class);
                    rightShift.setAccessible(true);
                    rightShift.invoke(blackBoxInt,number);
                    System.out.println(innerValue.get(blackBoxInt));
                    break;
            }

            command = scanner.nextLine();
        }
    }
}
