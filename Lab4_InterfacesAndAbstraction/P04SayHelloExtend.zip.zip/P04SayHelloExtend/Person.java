package P04SayHelloExtend;

public interface Person {

    String getName();
    String sayHello();
}
