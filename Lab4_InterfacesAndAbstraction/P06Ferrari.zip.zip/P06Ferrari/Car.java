package P06Ferrari;

public interface Car {

    String model = "488-Spider";
    String brakes();
    String gas();
}
